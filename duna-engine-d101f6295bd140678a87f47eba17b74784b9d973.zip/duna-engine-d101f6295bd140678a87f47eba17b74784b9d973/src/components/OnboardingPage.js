import React, { useState } from 'react';
import { initializeSovereignL3Workspace } from '../utils/web3Init.js';

export default function OnboardingPage() {
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState('');

    async function handleConnect() {
        setLoading(true);
        setStatus('Connecting to imToken Layer...');
        
        try {
            const success = await initializeSovereignL3Workspace();
            if (success) {
                setStatus('🚀 Sovereign L3 Network & $SC Token Connected Successfully!');
            } else {
                setStatus('❌ Connection aborted. Ensure you are inside the imToken web browser layer.');
            }
        } catch (err) {
            setStatus(`❌ Initialization runtime error: ${err.message}`);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div style={{
            fontFamily: 'system-ui, sans-serif',
            maxWidth: '500px',
            margin: '60px auto',
            padding: '30px',
            textAlign: 'center',
            background: '#111827',
            color: '#f9fafb',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.5)'
        }}>
            <h1 style={{ fontSize: '24px', color: '#3b82f6', marginBottom: '8px' }}>Sovereign-Credits-L3</h1>
            <p style={{ color: '#9ca3af', fontSize: '14px', marginBottom: '24px' }}>
                Onboard your workspace chain infrastructure to imToken
            </p>
            
            <button 
                onClick={handleConnect}
                disabled={loading}
                style={{
                    background: loading ? '#4b5563' : '#2563eb',
                    color: '#ffffff',
                    border: 'none',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: '600',
                    borderRadius: '8px',
                    cursor: loading ? 'not-allowed' : 'pointer',
                    transition: 'background 0.2s',
                    width: '100%'
                }}
            >
                {loading ? 'Processing Protocol...' : '🔌 Import to imToken Wallet'}
            </button>

            {status && (
                <p style={{ 
                    marginTop: '20px', 
                    fontSize: '13px', 
                    color: status.includes('🚀') ? '#10b981' : '#f87171',
                    background: '#1f2937',
                    padding: '10px',
                    borderRadius: '6px'
                }}>
                    {status}
                </p>
            )}
        </div>
    );
}
