import React from 'react';
import OnboardingPage from './components/OnboardingPage.js';

function App() {
  return (
    <div className="App" style={{ background: '#0b0f19', minHeight: '100vh', padding: '20px' }}>
      <OnboardingPage />
    </div>
  );
}

export default App;
