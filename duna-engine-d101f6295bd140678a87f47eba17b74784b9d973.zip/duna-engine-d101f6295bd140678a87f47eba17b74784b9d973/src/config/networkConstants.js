// Production L3 Configuration Metadata via Pinata IPFS Node
export const SOVEREIGN_L3_CONFIG = {
  cid: "QmQZg4FpZg1tN6Y7zE3L7k8V29gC3m9ZfXyBwH4p8J5Nq2",
  gatewayUrl: "https://ipfs.io",
  fallbackUrl: "https://eth.limo"
};
