import { SOVEREIGN_L3_CONFIG } from '../config/networkConstants.js';

/**
 * Initializes the Sovereign L3 execution environment inside an EVM web client or imToken WebView.
 */
export async function initializeSovereignL3Workspace() {
    const provider = window.ethereum;
    
    if (!provider) {
        console.error("❌ Web3 provider not found. Please load inside the imToken browser.");
        return;
    }

    try {
        console.log("🌐 Resolving production Layer-3 network metadata structures from IPFS...");
        
        const response = await fetch(SOVEREIGN_L3_CONFIG.gatewayUrl);
        const config = await response.json();
        
        const network = config.network;
        const tokens = config.tokens;

        console.log(`🔌 Requesting imToken to connect to chain: ${network.name}`);
        await provider.request({
            method: 'wallet_addEthereumChain',
            params: [{
                chainId: `0x${network.chainId.toString(16).toUpperCase()}`, 
                chainName: network.name,
                nativeCurrency: {
                    name: tokens.ETH.name,
                    symbol: tokens.ETH.symbol,
                    decimals: tokens.ETH.decimals
                },
                rpcUrls: ["https://eth.limo/rpc"], 
                blockExplorerUrls: ["https://arbiscan.io"] 
            }]
        });

        console.log(`🪙 Watch asset instruction targeting contract: ${tokens.SC.contract_address}`);
        await provider.request({
            method: 'wallet_watchAsset',
            params: {
                type: 'ERC20',
                options: {
                    address: tokens.SC.contract_address,
                    symbol: tokens.SC.symbol,
                    decimals: tokens.SC.decimals,
                    image: 'https://eth.limo/assets/sc-logo.png'
                }
            }
        });

        console.log("✅ Initialization successful! imToken layers are aligned with the IPFS CID configurations.");
        return true;

    } catch (error) {
        console.error("❌ Execution breakdown inside initialization workflow:", error);
        return false;
    }
}
